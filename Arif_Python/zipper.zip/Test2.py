# num=int(input("enter a number"))
# if num< 0:
#     print("a is negative number")

# if num > 0:
#     print("b is positive number")

# c = 7
# d = 4
# if c is (1,3,5,7):
#     print("c is an odd number")

# if d is (2,4,6,8):
#     print("d is an even number")

# hub=int(input("enter a number"))
# if hub < 0:
#     print("negative number")

# if hub > 0:
#     print("positive number")

# car=int(input("enter a number"))
# if car < 0:
#     print("negative number")

# if car > 0:
#     print("positive number")

# month = ["june","july","august"]
# for u in month:
#     if u == "june":
#         continue
#     print(u)
        



    
        


      